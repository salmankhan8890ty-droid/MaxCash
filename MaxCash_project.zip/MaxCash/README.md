# MaxCash Android demo

A simple Java Android demo UI for MaxCash with sample balance and buttons for Send Money, Mobile Load, Pay Bills, Bank Transfer, and Transaction History.

## Build an APK on GitHub
1. Upload the **contents** of this project folder to the root of your GitHub repository (not the PDF overview).
2. Open the repository's **Actions** tab.
3. Select **Build MaxCash APK** and press **Run workflow**, or push to `main` to trigger a build.
4. When the workflow finishes successfully, open the run and download the `MaxCash-debug-apk` artifact.

## Limitations
This is only a prototype. It does not connect to a bank or payment provider, and does not send, receive, store, or process real money. Do not enter real banking credentials or financial data. A real payment product needs a licensed provider, security review, and applicable regulatory approvals.
