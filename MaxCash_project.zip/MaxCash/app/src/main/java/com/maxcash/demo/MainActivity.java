package com.maxcash.demo;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + 0.5f); }
    private TextView label(String text, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(text); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); return t;
    }
    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(28), dp(24), dp(24)); root.setBackgroundColor(Color.rgb(246,249,247));
        scroll.addView(root);
        TextView title = label("MaxCash", 30, Color.rgb(17,106,58), true); title.setGravity(Gravity.CENTER); root.addView(title);
        TextView subtitle = label("Your money, organized", 15, Color.DKGRAY, false); subtitle.setGravity(Gravity.CENTER); subtitle.setPadding(0,dp(4),0,dp(22)); root.addView(subtitle);
        LinearLayout card = new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(dp(20),dp(20),dp(20),dp(20)); card.setBackgroundColor(Color.WHITE);
        TextView balTitle = label("Available balance (demo)", 16, Color.DKGRAY, false); card.addView(balTitle);
        TextView balance = label("PKR 25,000.00", 28, Color.rgb(17,106,58), true); balance.setPadding(0,dp(8),0,dp(4)); card.addView(balance);
        TextView note = label("Sample balance only — no real money is stored or transferred.", 12, Color.GRAY, false); card.addView(note);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(-1,-2); cp.bottomMargin=dp(20); root.addView(card,cp);
        String[][] actions = {{"Send Money","Demo only: transfers are not enabled."},{"Mobile Load","Demo only: mobile top-up is not enabled."},{"Pay Bills","Demo only: bill payments are not enabled."},{"Bank Transfer","Demo only: bank transfers are not enabled."},{"Transaction History","Demo only: no real transactions exist."}};
        for (String[] a : actions) { Button b = new Button(this); b.setText(a[0]); b.setAllCaps(false); b.setTextSize(16); LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,-2); p.bottomMargin=dp(10); root.addView(b,p); b.setOnClickListener(v -> Toast.makeText(this,a[1],Toast.LENGTH_LONG).show()); }
        TextView footer = label("Prototype app • Not a banking service", 12, Color.GRAY, false); footer.setGravity(Gravity.CENTER); footer.setPadding(0,dp(12),0,0); root.addView(footer);
        setContentView(scroll);
    }
}
